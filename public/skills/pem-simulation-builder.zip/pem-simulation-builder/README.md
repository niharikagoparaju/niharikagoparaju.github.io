# PEM Simulation Builder

An agent skill that helps pediatric emergency medicine educators build ready-to-run, in-person simulation packages (manikin-based, in situ or in a simulation center), consistent with the ASPiH Standards 2023. Type a topic, approve a one-screen outline, and get three editable Word documents you can review, pilot and run.

Version 2. Free to use under the MIT license.

## What you get

1. **Facilitator primer:** case at a glance, needs analysis, clinical background, recognition and management, a medication table with doses calculated for the patient, pitfalls, modality and fidelity choices, a prebrief script, confederate role cards, in-situ safety notes when relevant, an evaluation and pilot plan, and a table showing where each ASPiH standard is met.
2. **Simulation outline:** objectives, critical actions, supplies, a learner-facing opening, a four-column stage table (patient condition, expected interventions, instructor notes with triggers and cues), labs and image placeholders, and endpoint criteria.
3. **Debrief sheet:** structured in the PEARLS phases, with an observation checklist, case-specific questions and advocacy-inquiry prompts.

Doses and high-risk recommendations are checked against current guidance (2025 AHA/AAP PALS in the US, ERC 2025 in the UK and Europe) when the assistant can search the web. It flags what it couldn't confirm with **[VERIFY]**, and marks every document when it had no web access. Flags help you find weak spots; a clinician must still review everything.

## Install

Download `pem-simulation-builder.skill` (Claude) or `pem-simulation-builder.zip` (any platform). They are the same file.

- **claude.ai:** open Settings, find Skills (under Capabilities), and upload `pem-simulation-builder.skill` or the zip. Code execution must be enabled for Word output.
- **Claude Code:** unzip into `~/.claude/skills/` so you have `~/.claude/skills/pem-simulation-builder/SKILL.md`.
- **OpenAI Codex:** unzip into `~/.codex/skills/` (or a project's `.agents/skills/`) so you have `~/.codex/skills/pem-simulation-builder/SKILL.md`.
- **ChatGPT:** may work where ChatGPT supports skills; not tested. If Word files can't be made, the skill delivers Markdown with the same structure.

## Use

Ask in plain language, for example:

- "Build a simulation on DKA for our second-year PEM fellows."
- "Infant SVT sim, in situ in our ED, interprofessional team of nurses and residents."
- "Make a mock code for status epilepticus in a 4-year-old, 20 minutes, focus on teamwork."

The assistant states its assumptions, checks the clinical content, and shows you a short outline (needs analysis, objectives, patient, stage arc, modality, flagged risks). Approve it or ask for changes. It then writes the three documents, runs a self-check and sends the files with a list of items to verify.

## Important

This is an educational drafting tool, not clinical advice. Every package needs clinician review of the medical content (especially doses, flagged [VERIFY] items and local protocols) and a pilot run before use with learners. AI-generated content can be wrong in ways that look plausible.

## Standards and evidence

Designed to align with:

- Diaz-Navarro C, Laws-Chapman C, Moneypenny M, Purva M. The ASPiH Standards 2023: guiding simulation-based practice in health and care. https://aspih.org.uk/standards-2/
- INACSL Healthcare Simulation Standards of Best Practice: Simulation Design (Clin Simul Nurs. 2021;58:14-21) and the 2025 Prebriefing, Facilitation and Debriefing standards.
- Eppich W, Cheng A. Promoting Excellence and Reflective Learning in Simulation (PEARLS). Simul Healthc. 2015;10(2):106-115.
- Hernandez J, et al. Simulation Scenario Evaluation Tool (SSET). BMJ Simul Technol Enhanc Learn. 2020;6(6):344-350.

Informed by published work on AI-assisted scenario design, including:

- Barra FL, Rodella G, Costa A, et al. From prompt to platform: an agentic AI workflow for healthcare simulation scenario design. Adv Simul. 2025;10:29. doi:10.1186/s41077-025-00357-z
- Gupta K, Lavoie M, Guse S, Tay KY, Hrdy M. AI in simulation design: the effectiveness of a customized AI-based scenario development tool. Simul Healthc. 2026. doi:10.1097/SIH.0000000000000953
- Xu C, et al. Feasibility and challenges of LLM-generated neonatal resuscitation simulations. Scand J Trauma Resusc Emerg Med. 2026;34:121.
- Ghaffari F, et al. Effectiveness of ChatGPT for clinical scenario generation. Arch Acad Emerg Med. 2025;13(1):e49.
- Sumpter S. Automated generation of high-quality medical simulation scenarios through integration of semi-structured data and large language models. arXiv:2404.19713. 2024.

What these taught the skill: guide the model with structure, check doses and algorithm order, keep a person in the loop at the outline stage, vary patient demographics on purpose, never trust unverified references, and require expert review.

## Credits

The example outline in `references/reference-case-critical-coarc.md` (Critical Coarc) is used with permission of Erin Munns.

## License

MIT. See `LICENSE`.
