# Document specifications

Produce three clearly separated, coordinated documents. Keep patient details, weight, vitals, labs, doses, objectives and critical actions identical across all three. Write tersely: bold labels ending in a colon, short dash bullets, real tables. Use `references/reference-case-critical-coarc.md` as the structural and stylistic example for the outline.

Label management throughout as **Essential**, **Acceptable alternative** or **Local protocol** wherever practice varies.

If you drafted without web access, the first line of each of the three documents is this banner: **Drafted without web access:** every dose, rate and threshold is unverified and flagged [VERIFY]; a clinician must check all clinical content before use.

---

## Document 1. Facilitator primer

Three parts. Budget: Part A about 2 pages (at most about 1,000 words, tables included); Part B about 1 to 2 pages (at most about 1,000 words); Part C does not count toward the budget. To stay in budget: one line per bullet; give each fact once (doses live in the medication table, not again in prose); keep medication table cells to a few words; cut background and pitfalls before management, cues or required sections.

### Part A. Clinical primer (about 2 pages)

Lets a PEM faculty member unfamiliar with the topic prepare to run and debrief the case.

- **Case at a glance:** diagnosis, patient age, presentation, patient demographics and the one-line reason they were chosen, educational focus, intended endpoint.
- **Needs analysis:** one to three lines on the learning or system need this case addresses and for whom (curriculum item, known performance gap, rare high-risk event, incident learning).
- **Clinical background:** relevant pathophysiology and why the patient presents this way.
- **Recognition:** key history, examination findings, diagnostic clues, dangerous alternative diagnoses.
- **Management:** prioritized stabilization, definitive treatment, escalation, consultation, disposition. Name the guideline version used (see `references/clinical-verification.md`).
- **Medication reference:** the medication table from `references/clinical-verification.md` (Medication table section).
- **Common pitfalls:** likely learner errors, cognitive biases, management controversies.
- **Modality and fidelity:** why this modality and level of fidelity serve the objectives (manikin, standardized participant, task trainer, in situ vs sim center). Then **manikin-limitation cues**: findings the manikin can't show (capillary refill, fontanelle, work of breathing, skin color, mottling, mental status, rash, smell) and how each will be given: verbal cue from the nurse, card, monitor, photo.
- **Running the case:** essential cues, anticipated learner decisions, realistic responses to interventions, available rescue prompts.
- **Teaching priorities:** three to five points the facilitator should understand before the session.
- **References:** three to five authoritative sources, AMA format, with publication or update dates and links.

### Part B. Running the session (about 1 to 2 pages)

- **Prebrief script:** written to be read aloud, covering every element in `references/standards-alignment.md` (prebrief elements under ASPiH 10): purpose and whether this is assessment; running order and timings; ground rules and confidentiality; fiction contract; orientation to the manikin (what it can and can't do, how cues will be given), monitor and equipment; how to call for help or consultants; warning about emotionally difficult content and how to step out; faculty make mistakes too.
- **Faculty briefing:** two or three lines for co-faculty and the operator on the plan, the stage triggers and when to use rescue prompts.
- **Role cards:** one card for each confederate actually in the case (nurse, parent or caregiver, consultant on the phone, others), and only those. Each card: goal in the scenario; what they volunteer; what they give only (IF ASKED); prompts they may use if learners stall; lines they must not cross (e.g., don't diagnose, don't take over).
- **In-situ safety:** only when the setting is a real clinical area. Use the checklist in `references/standards-alignment.md` (In-situ safety section).
- **Evaluation and pilot plan:** a short participant and faculty evaluation (two or three questions tied to the objectives, plus feedback on the debrief); run a pilot with faculty or a small group before first use; record latent safety threats found and who they go to; note revisions with dates.

### Part C. Appendix: standards alignment

The alignment table from `references/standards-alignment.md` (Alignment table template section), with the third column filled with this package's actual section names.

---

## Document 2. Simulation outline

Follow this sequence and keep these headings from the reference simulation:

**Scenario:**
**Intended learners:**
**Target duration:**
**Developer:** [PLACEHOLDER]
**Last revision:** [DATE]

**Learning objectives:**
Three to five specific, observable objectives for the learner group, including clinical reasoning and teamwork or communication.

**Critical actions:**
A concise checklist of observable actions aligned with the objectives. Separate essential actions from optional or advanced actions.

**Location:**

**Supplies:**
- Manikin
- Equipment
- Medications
- Supporting files

**Brief narrative:**
A short case synopsis for the facilitator: presentation, intended trajectory, major decisions, endpoint. Include who is in the room: a parent or caregiver is present by default (played by a confederate) unless the educator says otherwise; if absent, state what learners are told if they ask.

**Learner-facing opening:**
Only the information the clinical team would receive at the start. Do not reveal the diagnosis. Visually separate it from facilitator-only content in a shaded box labeled "READ TO LEARNERS".

**Scenario progression:**
Use this exact four-column table:

| Scenario Stage | Patient Condition | Intervention | Notes for Instructor |
|---|---|---|---|

About three to five stages, adjusted to the case. Name stages as in the reference ("Stage 1", "Stage 3 - Apnea") and add approximate timing.

In **Patient Condition**: age and weight; vital signs with units; relevant history and examination findings; changes from the previous stage; results available at that point.

In **Intervention**: expected learner actions in priority order, with calculated doses matching the primer's medication table.

In **Notes for Instructor**:
- What is volunteered versus provided only if requested, marked "(IF ASKED)".
- Nurse, parent, consultant or other confederate dialogue when useful.
- The manikin-limitation cue for any finding the manikin can't show at this stage, and how it is given.
- Triggers for advancing to the next stage.
- Expected response and approximate timing after appropriate treatment.
- Consequences of delayed, omitted or inappropriate actions.
- A graduated cue if learners become stuck.
- Alternative acceptable management pathways.

Allow successful early recognition and treatment to change the course. Do not require deterioration, intubation or arrest unless clinically and educationally justified. Label any intentionally scripted complication **[SCRIPTED COMPLICATION]**. A branch stage reached only through omission is labeled as a branch, with its entry trigger and the action that resolves it.

**Laboratory Results:**
A table of realistic results:

| Test | Result | Units | Reference range |
|---|---|---|---|

Values must pass the consistency checks in `references/clinical-verification.md`. Include repeat results only if they support an objective.

**Images and Other Supporting Materials:**
List relevant ECGs, radiographs, ultrasound findings or other studies, the findings learners should identify, and when each becomes available. Use labeled placeholders, e.g. "[IMAGE PLACEHOLDER: Initial CXR - cardiomegaly, pulmonary edema; available Stage 1 when ordered]". Do not invent image links or present generated images as real studies. The facilitator inserts licensed images and their sources.

**Scenario endpoint:**
Explicit criteria for ending the scenario: stabilization, consultation, transfer or another appropriate outcome.

---

## Document 3. Facilitator debrief sheet

A practical one- to two-page sheet (at most about 1,000 words, tables included) for use during and right after the simulation, structured in the four PEARLS phases and aligned with the objectives and critical actions.

**1. Reactions**
- A brief, psychologically safe opening script that states the debrief is confidential and that performance in simulation is not a judgment of anyone's clinical practice.
- One or two questions inviting initial reactions.

**2. Description**
- A prompt for learners to summarize the case and their working diagnosis, so the group shares one picture of what happened.

**3. Analysis**

Observation checklist, using exactly this two-column table:

| Objective / Critical Action | Discussion and Notes |
|---|---|

Column 1: each objective or critical action written as an observable behavior, tagged with its objective number. Column 2: one short italic discussion prompt at the top, then open blank space (row height about 0.8 to 1 inch) for handwritten notes and timing. No Observed/Partial/Not Observed rating columns and no global competence judgment.

Guided analysis: four to six case-specific questions covering recognition and differential diagnosis; prioritization and treatment decisions; reassessment and response to deterioration; team roles, shared mental models and closed-loop communication; family communication or escalation of care when relevant.

For each major objective:
- an expected teaching point;
- a common misconception;
- an advocacy-inquiry question in neutral language: "I noticed [observation]. I was concerned about [clinical implication]. What was your thinking at that point?"

Performance-based prompts for both learners who recognized and treated the problem early, and learners who struggled, needed cues or chose an alternative pathway.

**4. Summary and transfer to practice**
- Ask learners to name two or three takeaways.
- Ask: "What will you do differently on your next clinical shift?"
- A concise facilitator summary of the essential lessons.
- Space for one individual learning goal and one team or system improvement.

---

## Formatting: Word

Default output is three separate, editable Word (.docx) files:

- `[Topic]_1_Facilitator_Primer.docx`
- `[Topic]_2_Simulation_Outline.docx`
- `[Topic]_3_Debrief_Sheet.docx`

How to build them: if a Word/docx tool or skill is available in this environment, use it. Otherwise generate the files with a script (for example Python with python-docx). Requirements: real Word tables (not tab-aligned text); 10 to 11 pt body text; bold section labels ending in a colon; header with the case title; footer with page numbers; landscape or narrow margins allowed for the four-column stage table; the learner-facing opening in a shaded box labeled "READ TO LEARNERS". If the environment can render to PDF or images, check the layout before sending.

Use Word unless the educator names another format.

## Formatting: Markdown fallback

If .docx files can't be produced in this environment (no tool, no ability to run scripts), deliver three Markdown files instead, and say why:

- `[Topic]_1_Facilitator_Primer.md`, `[Topic]_2_Simulation_Outline.md`, `[Topic]_3_Debrief_Sheet.md`
- Same headings and order as above.
- Real Markdown tables, including the exact four-column stage table and two-column debrief table. In the debrief table, leave note space as an empty Discussion and Notes cell (Word rows get height instead).
- The learner-facing opening as a blockquote whose first line is **READ TO LEARNERS**.
- If files can't be written at all, put the three documents in the reply, one after another, each under its file name as a heading.
