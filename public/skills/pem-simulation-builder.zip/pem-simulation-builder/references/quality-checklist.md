# Pre-delivery self-check

Run every item before building files. Fix what fails, then re-check. Do not send the package with a known failure; if something can't be fixed, flag it in the delivery reply.

## Consistency and accuracy

- [ ] Every learning objective appears in the scenario table and in the debrief checklist.
- [ ] Every essential critical action can actually be performed with the information, results and equipment provided (the needed lab, image, drug and device are in Supplies and available at the right stage).
- [ ] Weight, vitals and calculated doses match across all three documents; each calculated dose respects the stated maximum.
- [ ] Vitals change plausibly between stages and match the narrative (a stated hypoxemia shows in the exam and treatment).
- [ ] Labs pass the consistency checks in `clinical-verification.md` and are age-appropriate, in the region's units.
- [ ] Lab reference ranges are for the patient's age, not adult ranges; if unsure, flag [VERIFY: age-specific range].
- [ ] Exam findings fit the pathology and its side (pupils, gaze, motor side, murmurs, breath sounds).
- [ ] If the scenario simplifies the consequence of a dangerous action (e.g. an unsynchronised shock that causes no rhythm change), it is labeled a simplification in Notes for Instructor and the debrief states the real risk.
- [ ] Drug and step order follows the named guideline (no algorithm violations, such as a drug given before the step the guideline puts first).
- [ ] Care fits the stated setting: nothing that belongs to a different setting (e.g., NICU-only care in an ED case).
- [ ] Any checkpoint edits from the educator appear consistently in all three documents (recalculate weight, vitals and doses if age or weight changed).
- [ ] Anything that differs from the approved outline (a dose changed after verification, an added stage, branch, finding or result) is listed for the delivery reply under **Changes from the approved outline**.

## Scenario design

- [ ] Learner-facing opening does not reveal the diagnosis.
- [ ] Any scripted complication or branch stage is labeled and justified.
- [ ] History and exam are complete enough for learners to work the case; the case does not jump ahead faster than learners could reasonably act.
- [ ] The case covers all six SSET domains: learning objectives; context and overview; critical actions; patient states; materials and resources; debriefing.
- [ ] Patient demographics are deliberate and non-stereotyped; any social detail serves an objective.
- [ ] Manikin-limitation cues are given for findings the manikin can't show.
- [ ] Role cards exist for every confederate in the case and no others.
- [ ] Nothing from the Critical Coarc reference leaked into this case unless the topic calls for it.

## Standards

- [ ] The prebrief script covers every ASPiH 10 element listed in `standards-alignment.md`.
- [ ] The debrief follows the PEARLS phases, opens with confidentiality and the "not a judgment of clinical practice" statement, and uses advocacy-inquiry in analysis.
- [ ] In-situ safety notes are present if the setting is a real clinical area.
- [ ] An evaluation and pilot plan is present.
- [ ] Every row of the standards alignment table points to a section that actually exists in the three documents (not the chat outline).
- [ ] For any resuscitation content, the guideline version is named and current (2025 AHA/AAP PALS or ERC 2025).

## Sources

- [ ] References are real, dated and linked; nothing is cited that was not retrieved or known with certainty. Every source named anywhere in the package (including inside a flag or a stage note) is in the reference list.
- [ ] Every unverified dose, maximum, infusion range or threshold is flagged [VERIFY: reason] and listed for the delivery reply. With no web access, all of them are flagged inline in every document, including the stage table and the debrief sheet.

## Length

- [ ] Count the words in each part (for example in the script that builds the files): Primer Part A at most about 1,000 words; Part B at most about 1,000 words; the debrief sheet at most about 1,000 words; tables included. If a part is over, cut prose, repeated facts and background before required content, then count again.
- [ ] Bullets and tables, not textbook paragraphs. No em dashes in generated text.
