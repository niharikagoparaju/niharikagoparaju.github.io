# Standards alignment

The package is designed to meet the ASPiH Standards 2023 for simulation activity design. ASPiH sets principles, not a template, so INACSL Simulation Design criteria fill in what a scenario must contain. Use this file when drafting the primer's "Running the session" part and its standards appendix.

Citations:
- Diaz-Navarro C, Laws-Chapman C, Moneypenny M, Purva M. The ASPiH Standards 2023: guiding simulation-based practice in health and care. Association for Simulated Practice in Healthcare; 2023. https://aspih.org.uk/standards-2/
- Watts PI, et al. Healthcare Simulation Standards of Best Practice: Simulation Design. Clin Simul Nurs. 2021;58:14-21. doi:10.1016/j.ecns.2021.08.009
- INACSL 2025 revisions: Persico L, et al. Prebriefing: preparation and briefing. Clin Simul Nurs. 2025;105:101777. doi:10.1016/j.ecns.2025.101777. DiGregorio H, et al. Facilitation. Clin Simul Nurs. 2025;105:101776. doi:10.1016/j.ecns.2025.101776. Decker S, et al. The Debriefing Process. Clin Simul Nurs. 2025;105:101775. doi:10.1016/j.ecns.2025.101775.

## ASPiH 2023 standards used

| Standard | What it asks (paraphrase, key wording quoted) |
|---|---|
| 1 Core values | Safety (physical and psychological), equity, diversity and inclusion, sustainability, excellence |
| 5 Simulated participants | People playing patients, family or staff are briefed and prepared for their roles; casting considers EDI |
| 6 Learning outcomes | "The intended learning outcomes must be relevant and aligned with learning needs"; needs from curriculum, needs analysis or system sources; "The learning event should be piloted" |
| 7 Modality and fidelity | "The simulation modality, fidelity and activity design should be determined by the intended learning outcomes"; low fidelity may be enough |
| 8 Evaluation planned early | "Evaluation and research should be considered during the planning stage" |
| 9 Facilitation | Facilitators trained in psychological safety and debriefing; faculty briefing before the activity |
| 10 Prebriefing | "The activity must be initiated by a briefing or pre-briefing which helps create a safe environment where learning can take place" |
| 11 Purpose | The activity is run to achieve the intended learning outcomes and responds to needs that emerge |
| 12 Debriefing | "The simulated experience must include a facilitated reflection or debriefing in which the participants should explore and develop strategies to improve individual, team and system performance"; structured, outcome-focused, explores mental frames; simulated performance is not a marker of real practice |
| 14 Evaluation | Participant and faculty evaluation, including of debriefing and role portrayal; document latent safety threats; log revisions |

Prebrief elements ASPiH 10 expects (all go in the prebrief script): purpose and whether assessment is taking place; running order; ground rules and confidentiality; orientation to the environment, manikin and equipment; warning about emotionally difficult content and how it is handled (including opting out); lowering hierarchy ("faculty make mistakes too"); fiction contract; roles, including confederates; how to call for help or consultants.

## INACSL criteria used

Simulation Design (2021):
1. Designed with content experts and simulationists.
2. Needs assessment.
3. Measurable objectives.
4. Modality aligned with objectives.
5. Scenario with backstory, a script, clinical progression with cues, time frames and evidence-based critical actions.
6. Fidelity for realism (physical, conceptual, psychological).
7. Learner-centered facilitation plan.
8. Prebriefing plan.
9. Debriefing or feedback plan.
10. Evaluation plan.
11. Pilot test before full use.

The debriefing standard (2025) adds that the debrief should rest on a named theoretical framework; this package uses PEARLS (Eppich W, Cheng A. Simul Healthc. 2015;10(2):106-115. doi:10.1097/SIH.0000000000000072) with advocacy-inquiry from debriefing with good judgment (Rudolph JW, Simon R, Dufresne RL, Raemer DB. Simul Healthc. 2006;1(1):49-55. doi:10.1097/01266021-200600110-00006).

## Alignment table template

Put this table in the primer's appendix. Fill the third column with the actual section names used in this package; delete a row only if the standard truly does not apply and say why.

| Standard | What it asks | Where met in this package |
|---|---|---|
| ASPiH 1 Safety | Physical and psychological safety | Prebrief script; In-situ safety (if in situ); debrief opening |
| ASPiH 1 EDI | Inclusive, non-stereotyped design | Case at a glance (demographics and why chosen); role cards |
| ASPiH 5 | Prepared simulated participants | Role cards |
| ASPiH 6 / INACSL 2, 3 | Outcomes aligned to a learning need | Needs analysis; Learning objectives |
| ASPiH 7 / INACSL 4, 6 | Modality and fidelity chosen by outcomes | Modality and fidelity rationale; manikin-limitation cues |
| ASPiH 8, 14 / INACSL 10 | Evaluation planned and carried out | Evaluation and pilot plan |
| ASPiH 9 / INACSL 7 | Prepared facilitator | Clinical primer; Running the case notes |
| ASPiH 10 / INACSL 8 | Safe, structured prebrief | Prebrief script; READ TO LEARNERS box |
| ASPiH 11 / INACSL 5 | Scenario delivers the outcomes | Scenario progression table; critical actions |
| ASPiH 12 / INACSL 9 | Structured debrief | Debrief sheet (PEARLS) |
| ASPiH 6 / INACSL 11 | Pilot before use | Evaluation and pilot plan |

## Equity, diversity and inclusion

- Choose patient and family demographics deliberately and vary them across cases. Do not default to the same profile every time.
- Include a social detail (language, housing, insurance, family structure, ethnicity) only when it serves a learning objective, and never attach risk factors to a group without an educational reason.
- For cases that involve safeguarding or non-accidental trauma, avoid linking concern to race, class or family structure; the trigger should be clinical (history inconsistent with injury, developmental mismatch, injury pattern).
- Caregiver portrayal: a real person with understandable emotions, not a stereotype or an obstacle. If an interpreter is part of the case, make it a learning point, not color.
- Name stems and confederate scripts neutrally; check for microaggressions in dialogue.

## In-situ safety

Include in "Running the session" only when the case runs in a real clinical area:

- Simulation drugs and fluids clearly labeled "FOR SIMULATION ONLY", kept in a separate kit, counted in and out, never mixed with clinical stock.
- No live sharps on the manikin unless needed; sharps bin brought with the kit.
- Defibrillator: training device or manikin-safe setup; confirm it is returned to clinical mode afterwards.
- Signage at the bay ("Simulation in progress") and a briefing for staff nearby.
- A stop phrase (e.g., "real emergency, stop the simulation") and a plan to clear the space if a real patient needs it.
- Return the area to clinical readiness and record any latent safety threats found.
