# Reference case: Critical Coarc

Used with permission of Erin Munns.

**Structure and style only. Not a clinical source.** Do not reuse its clinical content (coarctation findings, prostaglandin, four-limb blood pressures, the 2-week-old vomiting presentation) in any other case. Use it to see the layout, label style and terseness the simulation outline should have.

Below is a text rendering of the original outline, followed by the patterns to keep and the inconsistencies not to copy.

```
Scenario: Cardiogenic shock, critical coarctation
Intended learners: PEM fellows
Target duration: 30 mins
Developer: Erin Munns
Last revision: 10/26

Learning objectives:
1) Demonstrate stabilization of sick neonate
2) Recognize cardiogenic shock/congenital heart disease
3) Demonstrate teamwork and closed loop communication

Critical actions:
-Assign team roles
-Place patient on monitors
-Obtain vascular access (IO)
-Obtain labs +/- imaging
-Recognize clinical decompensation
-Start PGE
-Secure airway

Location: Pediatric Emergency Department

Supplies:
Manikin: Infant
Equipment: -Braslow -Code cart -IO trainer, EZ IO -3.0 or 4.0 ETT, DL blades, end tidal -Ambu bag
Medications: -Normal Saline -PGE1 -D10 -Rocuronium -Etomidate, Versed/Fent, Ketamine
Supporting files: -Labs -CXR -Post intubation CXR

Brief narrative: 2 week old ex-term infant presents with vomiting and poor
feeding. Mom reports that for the past 2 days he has been vomiting with feeds.
Today has been sleepier than normal and seems pale. No fever, diarrhea, rash,
injuries.
Child should be placed on monitors and a targeted exam performed (Start with BP
cuff and O2 on R arm unless asked to move). Patient should have labs and imaging
ordered for lethargic neonate including POC BG. Difficulty obtaining IV requiring
IO. New onset congenital heart disease should be recognized and prostaglandin
started. Patient will become apneic after PGE requiring intubation.

Scenario progression:
| Scenario Stage | Patient Condition | Intervention | Notes for Instructor |

Stage 1
  Condition: Nurse brings infant back and grabs you saying patient seems slightly
    lethargic. Hx: Mom reports history as above. Weight: 3kg, Age 2 weeks.
    VS: T 37 HR 180 RR 60 BP 80/40 (R arm), 90%. POC BG: 25.
    Gen: floppy, lethargic, but with spontaneous movements of all limbs.
    HEENT: sunken font, PERRL. CV: Normal S1, S2. No murmurs. Weak lower limb
    and femoral pulses, normal upper limb pulses.
    4 limb BPs - RA 80/40 LA 82/44 RL 65/35 LL 67/40 (IF ASKED).
    Resp: crackles in bases, no inc WOB, tachypneic. Abd: soft, nontender.
    Skin: cap refill 4 secs, slightly gray.
  Intervention: Assess ABCs; Place on monitors; Get history (No recent illnesses
    or injuries; PMH none; PSH none; Allergies none; Social: lives with parents);
    Perform thorough exam; Check POC BG; Give D10; Request labs, CXR;
    Give differential for lethargic infant.
  Notes: If BG not checked, progress to seizure until corrected (seizures won't
    stop with benzos).

Stage 2
  Condition: Hypotension develops. Rhythm: NSR. HR 190/min. BP 40/20 legs,
    45/25 arms. RR 25/min. O2 sat 85%. Lethargic, eyes opening only to pain.
    Cap refill 6 sec.
  Intervention: Start PGE1 (0.05-0.1 mcg/kg/min). Consider small bolus vs need
    for pressors (epi initial 0.1 mcg/kg/min up to 1 mcg/kg/min).
  Notes: Nurse to prompt for 4 extremity BPs if not obtained yet. If PGE1 not
    started, will proceed to cardiac arrest (stage 4). If PGE1 started, will
    become apneic.

Stage 3 - Apnea
  Condition: RR 3, Sats 85%, HR 170, BP 55/40
  Intervention: Recognize need for intubation
  Notes: After patient intubated, improves and can call PICU for transfer

Stage 4 - Arrest
  Condition: HR 35, BP 40/20, Baby unresponsive
  Intervention: BMV or intubate; Start chest compressions
  Notes: Resolves if PGE given

Laboratory Results (free-form grid in original):
Na 140, K 5.6, Cl 105, HCO3 25, BUN 5, Cr 0.7, Glu 25
iCa 2.50, Mg 0.8, Albumin 3.5
VBG: pH 7.25, PCO2 50, PO2 95, HCO3 25, Lactate 3.0
WBC 18, Hg 14, Hct 35, Plt 550

Images (ECGs, CXRs, etc.) - two-column table, each cell = label with key
finding, embedded image, and source line:
  Initial CXR (CHF, cardiomegaly) | Post-intubation CXR
  ECG (sinus rhythm, extreme right-axis deviation)
```

**Patterns to keep:** bold labels with colons; terse dash bullets; Supplies split into bold sub-labels, one item per line; brief narrative that states the full intended trajectory; on-request history and findings in Notes for Instructor marked "(IF ASKED)"; Notes column written as if/then branch logic; stages named by event; images listed with the key finding in the caption, as labeled placeholders (the facilitator adds licensed images and their sources).

**Where this outline differs from `references/document-specs.md`, follow document-specs:** the original uses italic Supplies sub-labels, puts history answers in the Intervention column, and embeds sourced images.

**Do not copy (examples of inconsistencies to avoid):**
- Scripted deterioration that occurs regardless of performance (apnea after PGE is a real adverse effect, but should be labeled [SCRIPTED COMPLICATION] and the airway plan anticipated).
- Vitals that don't fit the stated physiology (e.g., arm BPs dropping in parallel with legs without explanation; RR falling from 60 to 25 while worsening shock is not explained).
- Labs inconsistent with the picture (normal HCO3 with pH 7.25 and lactate 3.0 implies a respiratory acidosis but bicarbonate does not reflect shock; ionized calcium value/units ambiguous).
- A Stage 1 finding (BG 25) shown up front while the Notes branch depends on BG not being checked; decide whether a value is volunteered or IF ASKED.
- Critical actions not split into essential vs optional, and objectives that are not observable.
- External image links reused without verification; use placeholders instead.