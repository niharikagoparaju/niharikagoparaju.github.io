# Clinical verification

Use during workflow step 2 (verify) and again while drafting. The goal: every dose, threshold and high-risk recommendation in the package is either verified against a dated source or visibly flagged.

## Source priority

Check sources in this order and stop when a current, authoritative answer is found:

1. The named resuscitation guideline for the region (see below), for anything resuscitation-related.
2. AAP clinical practice guidelines and pediatric specialty society guidelines (e.g., ISPAD for DKA, ACEP/AAP joint statements, RCEM/RCPCH guidance in the UK).
3. Recent systematic reviews or high-quality reviews on PubMed.
4. Drug label or national formulary: DailyMed/FDA label (US), BNF for Children (UK), or the local national formulary.
5. Other authoritative pediatric dosing references available to you.

Record each source used with publication or last-update date and a link. Prefer specific locations ("ISPAD 2022 Ch. 11, fluid recommendations") over general ones.

If a site refuses automated access (a login, paywall or bot check), treat that source as unavailable: don't try to get around the block. Use the next source on the list, or flag the number [VERIFY: source not accessible].

## Guideline versions by region

| Region | Resuscitation guideline | Notes |
|---|---|---|
| US (default) | 2025 AHA/AAP PALS: "Part 8: Pediatric Advanced Life Support: 2025 American Heart Association and American Academy of Pediatrics Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care." Circulation. 2025;152(16 suppl 2):S479-S537. doi:10.1161/CIR.0000000000001368 | Conventional US lab units (glucose mg/dL, creatinine mg/dL, BUN) |
| UK and Europe | ERC 2025 Paediatric Life Support: Djakow J, Turner NM, Skellett S, et al. European Resuscitation Council Guidelines 2025: Paediatric Life Support. Resuscitation. 2025;215 Suppl 1:110767. doi:10.1016/j.resuscitation.2025.110767. In the UK, also the Resuscitation Council UK 2025 guidelines. | SI units (glucose mmol/L, creatinine µmol/L, urea) |
| Elsewhere | Default to the US guideline and say so in the assumptions; use the user's national guideline if they name one | Ask about region at intake only if it changes dosing or units in this case |

Signals for region: spelling (paediatric, registrar, A&E), named institutions or systems (NHS, district general hospital), units the user writes. When unsure, keep the default and state it.

Do not cite superseded versions (2020 AHA, ERC 2021) for current recommendations.

## Flagging unverified content

- If a dose, maximum, infusion range, threshold or high-risk recommendation cannot be verified, keep it and flag it inline: **[VERIFY: reason]**, e.g. `[VERIFY: could not confirm max dose in current label]`.
- Collect every flag into the delivery reply under "Items to verify".
- **No web access:** say so in the assumptions at the top of the reply ("I have no web access in this session, so every dose and threshold below is from training knowledge and flagged [VERIFY]"). Then flag every dose, max dose, infusion range and numeric threshold, without exception, inline next to the number in every document where it appears: the medication table, the stage table and the debrief sheet. A note saying "all doses are flagged" does not replace the inline flags. Numbers that are easy to miss count too: administration time or rate (e.g. "over 5 to 10 min"), an age cut-off in a drug caution (e.g. "avoid under 2 years"), and positioning or physiologic targets (e.g. head of bed 30°, SpO2 or EtCO2 ranges). Also put the offline banner at the top of each document (see `references/document-specs.md`), because the documents travel without the chat. Values you chose for the scenario (the patient's weight, vitals, GCS, exam findings, lab results) are scenario-chosen, not thresholds: don't flag them, but do flag the reference ranges and targets they are judged against.
- Quote contraindications and warnings at the source's strength ("should not be used under 1 year" stays a prohibition, not "covers over 12 months").
- Never invent a reference, DOI, URL, page number or quotation to make an item look verified. A flag is always better than a fabricated source.
- Every source you name, including one named inside a [VERIFY] flag or an instructor note, goes in the primer's reference list with its date and link. With no web access, give the date and write [VERIFY: link not retrieved] in place of the link. Don't cite a source you saw only as a search snippet; flag the number instead.

## Medication table

In the facilitator primer, list every medication the case uses in one table:

| Drug | Indication | Dose (per kg) | Calculated dose for this patient | Route | Max dose | Precautions |
|---|---|---|---|---|---|---|

- Calculate the dose for this patient's weight and cap it at the stated maximum; say "(capped at max)" when the cap applies.
- Infusions: give units (mcg/kg/min, units/kg/h), starting rate and titration range.
- Label each row Essential, Acceptable alternative or Local protocol when management varies.
- The same calculated doses must appear in the outline's Intervention column.

## Consistency checks

Run these on every set of vitals and results before the self-check:

- **Weight:** plausible for age (state the growth reference or length-based tape band used).
- **Vitals:** age-appropriate; name the reference used (e.g., PALS vital sign ranges). Abnormal values must fit the physiology and the stage.
- **Anion gap:** Na − (Cl + HCO3); state it if the case teaches it.
- **Respiratory compensation:** for metabolic acidosis, expected PaCO2 ≈ 1.5 × HCO3 + 8 (± 2) (Winter's formula).
- **Lactate vs bicarbonate:** a raised lactate or ketoacidosis must lower bicarbonate.
- **Corrected sodium** in hyperglycemia, where the case uses it, and show the formula used.
- **Potassium** in acidosis: plausible for the acid-base state; total body depletion noted where relevant (e.g., DKA).
- **Calcium:** ionized vs total, with units, never ambiguous.
- **Units:** match the region throughout (mg/dL vs mmol/L); never mix within a document.
- **Repeat results:** only when they serve an objective, and they must move in the direction the treatment would cause.

## Reference format

AMA style, each with publication or update date and a link or DOI. Three to five references in the primer, chosen for the facilitator. Only cite sources you actually retrieved in this session or know with certainty; otherwise flag the claim instead.
